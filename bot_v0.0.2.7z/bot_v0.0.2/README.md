# 🤖 AI-Фриланс Ассистент - Version 0.0.2

**Улучшенная версия** Telegram-бота для автоматизации откликов на фриланс-биржах

## 🆕 Что нового в версии 0.0.2

- ✅ **Регистрация пользователей** - автоматическая при первом запуске
- ✅ **Система профилей** - хранение данных пользователя
- ✅ **Inline-кнопки** - удобная навигация вместо текстовых команд
- ✅ **Supabase интеграция** - PostgreSQL вместо JSON
- ✅ **Улучшенная обработка ошибок** - глобальный handler
- ✅ **Миграция данных** - перенос из версии 0.0.1

## 📦 Установка

### 1. Установите зависимости

```bash
pip install -r requirements.txt
```

### 2. Настройте Supabase

1. Создайте проект на [supabase.com](https://supabase.com)
2. Скопируйте URL и API Key из Settings → API
3. Создайте таблицы из файла `database/schema.sql` в SQL Editor

Подробная инструкция: [SUPABASE_SETUP.md](./SUPABASE_SETUP.md)

### 3. Настройте переменные окружения

```bash
# Скопируйте шаблон
cp .env.example .env

# Отредактируйте .env и добавьте свои данные
```

Пример `.env`:
```env
BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your_supabase_anon_key
```

### 4. Миграция из версии 0.0.1 (опционально)

Если у вас есть данные из версии 0.0.1:

```bash
python migrations/migrate_from_json.py
```

## 🚀 Запуск

```bash
python bot.py
```

Если все настроено правильно, увидите:
```
🤖 Бот версии 0.0.2 запущен!
Нажми Ctrl+C для остановки
```

## 🎮 Использование

### Команды

- `/start` - Регистрация и главное меню
- `/profile` - Просмотр профиля
- `/tasks` - Список заданий
- `/balance` - Проверка баланса
- `/my_responses` - История откликов

### Inline-кнопки

После `/start` доступны кнопки:
- 📋 **Список заданий** - просмотр доступных заданий
- ✍️ **Мои отклики** - история ваших откликов
- 💰 **Баланс** - текущий баланс и статистика
- 🧾 **Профиль** - ваш профиль
- 🔧 **Настройки** - настройки (в разработке)

## 📁 Структура проекта

```
bot_v0.0.2/
├── bot.py                    # Точка входа
├── config.py                 # Конфигурация
├── .env                      # Переменные окружения (не в Git)
├── .env.example              # Шаблон переменных
├── requirements.txt          # Зависимости
├── database/                 # База данных
│   ├── supabase_client.py
│   ├── models.py
│   └── schema.sql
├── services/                 # Бизнес-логика
│   ├── user_service.py
│   ├── task_service.py
│   └── ai_service.py
├── handlers/                 # Обработчики
│   ├── start_handler.py
│   ├── profile_handler.py
│   ├── tasks_handler.py
│   ├── balance_handler.py
│   └── callback_handler.py
├── keyboards/                # Клавиатуры
│   └── inline_keyboards.py
├── utils/                    # Утилиты
│   └── error_handler.py
└── migrations/               # Миграции
    └── migrate_from_json.py
```

## 🗄️ База данных

### Таблица users

| Поле | Тип | Описание |
|------|-----|----------|
| id | BIGSERIAL | Primary key |
| user_id | BIGINT | Telegram user ID (unique) |
| username | TEXT | Telegram username |
| balance | NUMERIC | Баланс в рублях |
| completed_tasks | INTEGER | Количество выполненных заданий |
| role | TEXT | Роль (free/pro) |
| created_at | TIMESTAMP | Дата регистрации |

### Таблица responses

| Поле | Тип | Описание |
|------|-----|----------|
| id | BIGSERIAL | Primary key |
| user_id | BIGINT | Foreign key → users |
| task_id | INTEGER | ID задания |
| task_title | TEXT | Название задания |
| response_text | TEXT | Текст отклика |
| earned | NUMERIC | Заработано рублей |
| created_at | TIMESTAMP | Дата отклика |

## 🔧 Разработка

### Запуск в режиме разработки

```bash
# Активировать виртуальное окружение
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# Установить зависимости
pip install -r requirements.txt

# Запустить бота
python bot.py
```

### Тестирование

```bash
# Запустить тесты (когда будут добавлены)
pytest tests/
```

## 🛠️ Troubleshooting

### Ошибка: "BOT_TOKEN не найден"
- Проверьте наличие файла `.env`
- Убедитесь, что токен скопирован правильно

### Ошибка: "SUPABASE_URL не найден"
- Создайте проект на supabase.com
- Скопируйте URL и API Key в `.env`

### Бот не отвечает
- Проверьте, что бот запущен
- Проверьте интернет-соединение
- Проверьте логи на ошибки

### Ошибка подключения к Supabase
- Проверьте правильность SUPABASE_URL и SUPABASE_KEY
- Убедитесь, что таблицы созданы в Supabase
- Проверьте Row Level Security (RLS) настройки

## 📚 Документация

- [SUPABASE_SETUP.md](./SUPABASE_SETUP.md) - Настройка Supabase
- [MIGRATION.md](./MIGRATION.md) - Миграция из v0.0.1
- [API.md](./API.md) - API документация

## 🔄 Обновление с версии 0.0.1

1. Установите новые зависимости
2. Настройте Supabase
3. Запустите миграцию данных
4. Запустите новую версию бота

Подробнее: [MIGRATION.md](./MIGRATION.md)

## 📋 TODO: Версия 0.0.3

- 🤖 Реальная AI-генерация (OpenAI/YandexGPT)
- 🔗 Интеграция с API фриланс-бирж
- 💳 Система подписок (Free/Pro)
- 💸 Платежная система
- 🌐 Веб-интерфейс
- 📊 Аналитика и статистика

## 📄 Лицензия

MIT License

## 🤝 Поддержка

Если нашли баг или есть предложения:
- Создайте issue в репозитории
- Опишите проблему подробно
- Приложите логи/скриншоты

---

**Версия:** 0.0.2  
**Дата:** 14.11.2025  
**Статус:** ✅ Готов к использованию

**Удачи! 🚀**
