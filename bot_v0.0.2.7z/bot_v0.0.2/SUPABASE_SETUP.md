# 🗄️ Настройка Supabase для AI-Фриланс Ассистент

Пошаговая инструкция по настройке базы данных Supabase для версии 0.0.2 бота.

## 📋 Что такое Supabase?

Supabase — это открытая альтернатива Firebase, предоставляющая:
- PostgreSQL базу данных
- REST API для работы с данными
- Аутентификацию пользователей
- Хранилище файлов
- Real-time подписки

Для нашего бота мы используем PostgreSQL и REST API.

## 🚀 Шаг 1: Создание проекта

### 1.1 Регистрация

1. Перейдите на [supabase.com](https://supabase.com)
2. Нажмите **Start your project**
3. Войдите через GitHub или создайте аккаунт

### 1.2 Создание проекта

1. Нажмите **New Project**
2. Выберите организацию (или создайте новую)
3. Заполните данные проекта:
   - **Name**: `freelance-bot` (или любое другое имя)
   - **Database Password**: Придумайте надежный пароль (сохраните его!)
   - **Region**: Выберите ближайший регион (например, `Europe West (London)`)
   - **Pricing Plan**: Free (для начала)
4. Нажмите **Create new project**

⏱️ Создание проекта займет 1-2 минуты.

## 🔑 Шаг 2: Получение API ключей

### 2.1 Где найти ключи

1. В левом меню выберите **Settings** (⚙️)
2. Перейдите в **API**
3. Найдите секцию **Project API keys**

### 2.2 Какие ключи нужны

Вам понадобятся:

- **Project URL** - URL вашего проекта
  ```
  https://your-project-id.supabase.co
  ```

- **anon public** - Публичный API ключ
  ```
  eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
  ```

⚠️ **Важно**: Не используйте `service_role` ключ в клиентском коде!

### 2.3 Сохранение ключей

Скопируйте ключи в файл `.env`:

```env
SUPABASE_URL=https://your-project-id.supabase.co
SUPABASE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

## 📊 Шаг 3: Создание таблиц

### 3.1 Открытие SQL Editor

1. В левом меню выберите **SQL Editor**
2. Нажмите **New query**

### 3.2 Выполнение SQL скрипта

1. Откройте файл `database/schema.sql` из проекта
2. Скопируйте весь SQL код
3. Вставьте в SQL Editor
4. Нажмите **Run** (или `Ctrl+Enter`)

✅ Вы должны увидеть сообщение: **Success. No rows returned**

### 3.3 Проверка таблиц

1. В левом меню выберите **Table Editor**
2. Вы должны увидеть две таблицы:
   - `users` - таблица пользователей
   - `responses` - таблица откликов

### 3.4 Структура таблиц

#### Таблица `users`

| Колонка | Тип | Описание |
|---------|-----|----------|
| id | bigint | Primary key (автоинкремент) |
| user_id | bigint | Telegram user ID (уникальный) |
| username | text | Telegram username |
| balance | numeric | Баланс в рублях |
| completed_tasks | integer | Количество заданий |
| role | text | Роль (free/pro) |
| created_at | timestamp | Дата регистрации |

#### Таблица `responses`

| Колонка | Тип | Описание |
|---------|-----|----------|
| id | bigint | Primary key (автоинкремент) |
| user_id | bigint | Foreign key → users |
| task_id | integer | ID задания |
| task_title | text | Название задания |
| response_text | text | Текст отклика |
| earned | numeric | Заработано рублей |
| created_at | timestamp | Дата отклика |

## 🔒 Шаг 4: Настройка безопасности (опционально)

### 4.1 Row Level Security (RLS)

По умолчанию RLS отключен для упрощения разработки.

Для production рекомендуется включить:

1. Перейдите в **Authentication** → **Policies**
2. Выберите таблицу `users`
3. Нажмите **New Policy**
4. Создайте политики доступа

Пример политики:
```sql
CREATE POLICY "Users can view their own data" ON users
    FOR SELECT USING (auth.uid() = user_id);
```

### 4.2 API Rate Limiting

В бесплатном плане Supabase:
- 500 MB базы данных
- 1 GB трафика
- 50,000 запросов в месяц

Для production рассмотрите платный план.

## ✅ Шаг 5: Проверка подключения

### 5.1 Тестовый запрос

В SQL Editor выполните:

```sql
SELECT * FROM users LIMIT 5;
```

Должен вернуться пустой результат (таблица пока пуста).

### 5.2 Проверка через бота

1. Убедитесь, что `.env` файл заполнен
2. Запустите бота:
   ```bash
   python bot.py
   ```
3. Отправьте `/start` в Telegram
4. Зарегистрируйтесь
5. Проверьте в Supabase Table Editor - должна появиться запись в `users`

## 🔧 Troubleshooting

### Ошибка: "Invalid API key"

**Причина**: Неправильный SUPABASE_KEY

**Решение**:
1. Проверьте, что скопировали `anon public` ключ
2. Убедитесь, что нет лишних пробелов
3. Перезапустите бота

### Ошибка: "relation 'users' does not exist"

**Причина**: Таблицы не созданы

**Решение**:
1. Откройте SQL Editor
2. Выполните `database/schema.sql`
3. Проверьте в Table Editor

### Ошибка: "Failed to fetch"

**Причина**: Проблемы с сетью или неправильный URL

**Решение**:
1. Проверьте SUPABASE_URL
2. Убедитесь, что проект активен
3. Проверьте интернет-соединение

### Таблицы созданы, но бот не может записать данные

**Причина**: RLS политики блокируют запись

**Решение**:
1. Перейдите в Table Editor → `users`
2. Нажмите на иконку замка
3. Выберите **Disable RLS**
4. Повторите для таблицы `responses`

## 📊 Мониторинг и статистика

### Просмотр данных

1. **Table Editor** - просмотр и редактирование данных
2. **SQL Editor** - выполнение SQL запросов
3. **Database** → **Roles** - управление доступом

### Полезные SQL запросы

```sql
-- Количество пользователей
SELECT COUNT(*) FROM users;

-- Топ пользователей по балансу
SELECT username, balance, completed_tasks 
FROM users 
ORDER BY balance DESC 
LIMIT 10;

-- Статистика откликов
SELECT 
    COUNT(*) as total_responses,
    SUM(earned) as total_earned,
    AVG(earned) as avg_earned
FROM responses;

-- Активность по дням
SELECT 
    DATE(created_at) as date,
    COUNT(*) as responses_count
FROM responses
GROUP BY DATE(created_at)
ORDER BY date DESC;
```

## 🔄 Бэкапы

### Автоматические бэкапы

Supabase автоматически создает бэкапы:
- **Free plan**: Бэкапы за последние 7 дней
- **Pro plan**: Бэкапы за последние 30 дней

### Ручной экспорт

1. Перейдите в **Database** → **Backups**
2. Нажмите **Download backup**
3. Сохраните `.sql` файл

### Восстановление

```bash
# Через psql (если установлен)
psql -h db.your-project.supabase.co -U postgres -d postgres -f backup.sql
```

## 📈 Масштабирование

### Когда нужен апгрейд?

Переходите на платный план если:
- Более 500 MB данных
- Более 50,000 запросов в месяц
- Нужны дополнительные функции (Point-in-time recovery, Custom domains)

### Планы Supabase

- **Free**: $0/месяц - для разработки
- **Pro**: $25/месяц - для production
- **Team**: $599/месяц - для команд
- **Enterprise**: Custom - для крупных проектов

## 🎓 Дополнительные ресурсы

- [Supabase Documentation](https://supabase.com/docs)
- [PostgreSQL Tutorial](https://www.postgresql.org/docs/current/tutorial.html)
- [Supabase Python Client](https://github.com/supabase-community/supabase-py)
- [Supabase Discord](https://discord.supabase.com)

## ✅ Чек-лист готовности

Перед запуском бота убедитесь:

- [ ] Проект Supabase создан
- [ ] Таблицы `users` и `responses` созданы
- [ ] SUPABASE_URL скопирован в `.env`
- [ ] SUPABASE_KEY скопирован в `.env`
- [ ] RLS отключен (для разработки)
- [ ] Тестовый запрос в SQL Editor работает
- [ ] Бот успешно запускается без ошибок

---

**Готово!** 🎉 Теперь ваш бот готов работать с Supabase.

Следующий шаг: [Запуск бота](./README.md#-запуск)
