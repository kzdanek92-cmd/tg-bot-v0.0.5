# ⚡ Быстрый старт - AI-Фриланс Ассистент v0.0.2

## 3 шага до запуска:

### 1️⃣ Установи зависимости
```bash
cd bot_v0.0.2
pip install -r requirements.txt
```

### 2️⃣ Настрой Supabase и переменные окружения

**A. Создай проект Supabase:**
1. Перейди на [supabase.com](https://supabase.com)
2. Создай новый проект
3. Скопируй URL и API Key из Settings → API

**B. Создай таблицы:**
1. Открой SQL Editor в Supabase
2. Скопируй и выполни `database/schema.sql`

**C. Настрой .env:**
```bash
# Скопируй шаблон
cp .env.example .env

# Отредактируй .env и добавь свои данные:
BOT_TOKEN=твой_токен_от_BotFather
SUPABASE_URL=https://твой-проект.supabase.co
SUPABASE_KEY=твой_supabase_anon_key
```

📚 Подробная инструкция: [SUPABASE_SETUP.md](./SUPABASE_SETUP.md)

### 3️⃣ Запусти бота
```bash
python bot.py
```

---

## 🔄 Миграция из версии 0.0.1 (опционально)

Если у тебя есть данные из версии 0.0.1:

```bash
python migrations/migrate_from_json.py
```

---

## 🧪 Тестовые команды:

Открой бота в Telegram и попробуй:

```
/start          # Регистрация и главное меню
📋 Список заданий  # Через inline кнопку
✍️ Откликнуться    # На любое задание
💰 Баланс          # Проверить баланс
🧾 Профиль         # Посмотреть профиль
```

---

## ❓ Проблемы?

### Ошибка: "BOT_TOKEN не найден"
- Проверь, что файл `.env` создан
- Убедись, что токен скопирован правильно

### Ошибка: "SUPABASE_URL не найден"
- Проверь, что `.env` содержит SUPABASE_URL и SUPABASE_KEY
- Убедись, что проект Supabase создан

### Бот не отвечает
- Проверь, что `python bot.py` запущен
- Проверь логи в файле `bot.log`

---

**Готово! 🎉**

Подробная документация: [README.md](./README.md)
