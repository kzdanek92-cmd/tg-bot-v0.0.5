"""
Payments Module
Модуль для работы с платежами
"""

from .crypto import CryptoPaymentService

__all__ = ['CryptoPaymentService']
