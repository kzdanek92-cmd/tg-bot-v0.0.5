"""
Info Handler
Обработчик информационных разделов (О проекте, Команда, Планы)
"""

import logging
from aiogram import Router
from aiogram.types import CallbackQuery
from ui.menus import get_about_menu, get_team_menu, get_future_menu, get_main_menu, get_agreement_menu

logger = logging.getLogger(__name__)

router = Router()


async def show_about_project(callback: CallbackQuery):
    """Показать раздел "О проекте" """
    try:
        text = """
🧱 <b>О проекте</b>

Этот бот создан как система <b>автоматического фриланса</b> — он сам ищет заказы, откликается, выполняет задачи и приносит прибыль.

<b>Цель проекта:</b>
Создать полноценный инструмент пассивного заработка, где искусственный интеллект работает за людей — от откликов до выполнения заказов.

<b>Как это работает:</b>
• 🤖 ИИ анализирует задания на фриланс-биржах
• ✍️ Автоматически генерирует персонализированные отклики
• 💼 Выполняет простые задачи самостоятельно
• 💰 Приносит прибыль пользователям

<b>Для кого этот проект:</b>
• Люди, которые хотят зарабатывать пассивно
• Фрилансеры, которым нужен помощник
• Те, кто не может работать самостоятельно

<i>Мы верим, что технологии должны работать на людей, а не наоборот.</i>
"""
        await callback.message.edit_text(
            text,
            reply_markup=get_about_menu(),
            parse_mode="HTML"
        )
        await callback.answer()
        
    except Exception as e:
        logger.error(f"Ошибка в show_about_project: {e}")
        await callback.answer("😔 Ошибка", show_alert=True)


async def show_team(callback: CallbackQuery):
    """Показать раздел "Команда" """
    try:
        text = """
👑 <b>Команда проекта</b>

<b>Основатель:</b> @Danyadlyalubvi2
<b>Возраст:</b> 20 лет
<b>Статус:</b> инвалид 1 группы

<b>История создания:</b>
Всегда мечтал создать систему, где ИИ работает за людей — от откликов до выполнения заказов. 

Этот проект — шаг к тому, чтобы люди могли зарабатывать, даже когда не могут работать самостоятельно.

<b>Миссия:</b>
Сделать заработок доступным для всех, независимо от физических возможностей или жизненных обстоятельств.

<b>Технологии:</b>
• Python + aiogram
• Supabase (PostgreSQL)
• AI/ML для генерации откликов
• CryptoBot API для платежей

<i>"Технологии должны помогать людям жить лучше" - основатель проекта</i>
"""
        await callback.message.edit_text(
            text,
            reply_markup=get_team_menu(),
            parse_mode="HTML"
        )
        await callback.answer()
        
    except Exception as e:
        logger.error(f"Ошибка в show_team: {e}")
        await callback.answer("😔 Ошибка", show_alert=True)


async def show_future_plans(callback: CallbackQuery):
    """Показать раздел "Планы на будущее" """
    try:
        text = """
🚀 <b>Планы на будущее</b>

<b>Версия 0.0.5 (ближайшая):</b>
🔧 Подключение рублевых платёжных шлюзов
💳 ЮKassa / Stripe интеграция
📊 Расширенная статистика

<b>Версия 0.1.0:</b>
🧠 Собственная модель ИИ на основе собранных заданий
🎯 Улучшенная генерация откликов
📈 Анализ успешности откликов

<b>Версия 0.2.0:</b>
🧾 Авто-портфолио из выполненных работ
📸 Генерация примеров работ
⭐ Система рейтингов

<b>Версия 0.3.0:</b>
🌍 Выход на международные биржи:
   • Fiverr
   • Upwork
   • Freelancer
   • Guru

<b>Версия 1.0.0:</b>
💎 Внедрение подписок PRO и ULTRA
🤖 Полностью автономная работа ИИ
💼 Автоматическое выполнение заданий
🏆 Система достижений и бонусов

<b>Долгосрочные цели:</b>
• Создание маркетплейса ИИ-фрилансеров
• Обучение ИИ на реальных заказах
• Масштабирование на другие платформы
• Создание сообщества пользователей

<i>Мы только начали путь к полной автоматизации фриланса! 🚀</i>
"""
        await callback.message.edit_text(
            text,
            reply_markup=get_future_menu(),
            parse_mode="HTML"
        )
        await callback.answer()
        
    except Exception as e:
        logger.error(f"Ошибка в show_future_plans: {e}")
        await callback.answer("😔 Ошибка", show_alert=True)


async def show_agreement(callback: CallbackQuery):
    """Показать пользовательское соглашение"""
    try:
        text = """
📜 <b>Пользовательское соглашение</b>

<b>1. Общие положения</b>
Используя этот бот, вы соглашаетесь с условиями использования.

<b>2. Описание сервиса</b>
Бот предоставляет автоматизированные инструменты для работы на фриланс-биржах.

<b>3. Ответственность</b>
• Бот находится в стадии разработки (beta)
• Мы не гарантируем 100% доступность сервиса
• Пользователь несет ответственность за свои действия

<b>4. Платежи</b>
• Все платежи обрабатываются через CryptoBot
• Возврат средств возможен в течение 14 дней
• Комиссии платежных систем не возвращаются

<b>5. Конфиденциальность</b>
• Мы не передаем ваши данные третьим лицам
• Данные хранятся в защищенной базе Supabase
• Вы можете запросить удаление данных

<b>6. Изменения</b>
Мы оставляем за собой право изменять условия соглашения.

<b>Дата последнего обновления:</b> 14.11.2025
<b>Версия:</b> 1.0

<i>Нажимая "Принимаю", вы соглашаетесь с условиями</i>
"""
        await callback.message.edit_text(
            text,
            reply_markup=get_agreement_menu(),
            parse_mode="HTML"
        )
        await callback.answer()
        
    except Exception as e:
        logger.error(f"Ошибка в show_agreement: {e}")
        await callback.answer("😔 Ошибка", show_alert=True)


async def accept_agreement(callback: CallbackQuery):
    """Принятие соглашения"""
    await callback.answer("✅ Спасибо! Соглашение принято.", show_alert=False)
    # Можно сохранить в БД что пользователь принял соглашение
    await show_main_menu(callback)


async def show_main_menu(callback: CallbackQuery):
    """Показать главное меню"""
    try:
        text = """
🏠 <b>Главное меню</b>

Выберите раздел:
"""
        await callback.message.edit_text(
            text,
            reply_markup=get_main_menu(),
            parse_mode="HTML"
        )
        await callback.answer()
        
    except Exception as e:
        logger.error(f"Ошибка в show_main_menu: {e}")
        await callback.answer("😔 Ошибка", show_alert=True)


def register_handlers(router: Router):
    """Регистрация обработчиков информационных разделов"""
    router.callback_query.register(show_about_project, lambda c: c.data == "about_project")
    router.callback_query.register(show_team, lambda c: c.data == "team")
    router.callback_query.register(show_future_plans, lambda c: c.data == "future_plans")
    router.callback_query.register(show_agreement, lambda c: c.data == "agreement")
    router.callback_query.register(accept_agreement, lambda c: c.data == "accept_agreement")
    router.callback_query.register(show_main_menu, lambda c: c.data == "main_menu")
