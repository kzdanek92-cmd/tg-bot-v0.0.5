"""
Payments Handler
Обработчик платежей через CryptoBot
"""

import logging
from aiogram import Router
from aiogram.types import CallbackQuery
from payments.crypto import CryptoPaymentService
from services.user_service import UserService
from ui.menus import (
    get_payment_menu,
    get_ton_amount_menu,
    get_payment_confirmation_menu,
    get_main_menu
)

logger = logging.getLogger(__name__)

router = Router()

# Временное хранилище для счетов (в production использовать Redis или БД)
pending_invoices = {}


async def show_payment_menu(callback: CallbackQuery):
    """Показать меню выбора способа оплаты"""
    try:
        text = """
💳 <b>Пополнение баланса</b>

Выберите способ оплаты:

🪙 <b>TON</b> - быстро и без комиссий
💎 <b>USDT</b> - скоро
💳 <b>Банковская карта</b> - скоро

<i>После пополнения баланс будет автоматически зачислен на ваш аккаунт</i>
"""
        await callback.message.edit_text(
            text,
            reply_markup=get_payment_menu(),
            parse_mode="HTML"
        )
        await callback.answer()
        
    except Exception as e:
        logger.error(f"Ошибка в show_payment_menu: {e}")
        await callback.answer("😔 Ошибка", show_alert=True)


async def show_ton_amount_menu(callback: CallbackQuery, crypto_service: CryptoPaymentService):
    """Показать меню выбора суммы в TON"""
    try:
        if not crypto_service:
            await callback.answer(
                "😔 CryptoBot не настроен. Обратитесь к администратору.",
                show_alert=True
            )
            return
            
        text = """
🪙 <b>Пополнение через TON</b>

Выберите сумму для пополнения:

<i>1 TON ≈ 50₽ (курс может меняться)</i>

После выбора суммы вы получите ссылку для оплаты через CryptoBot.
"""
        await callback.message.edit_text(
            text,
            reply_markup=get_ton_amount_menu(),
            parse_mode="HTML"
        )
        await callback.answer()
        
    except Exception as e:
        logger.error(f"Ошибка в show_ton_amount_menu: {e}")
        await callback.answer("😔 Ошибка", show_alert=True)


async def create_ton_invoice(
    callback: CallbackQuery,
    crypto_service: CryptoPaymentService,
    amount: float
):
    """Создать счет для оплаты в TON"""
    try:
        user_id = callback.from_user.id
        
        # Создаем счет
        invoice = await crypto_service.create_invoice(
            amount=amount,
            currency="TON",
            description=f"Пополнение баланса на {amount} TON",
            payload=str(user_id)
        )
        
        if not invoice:
            await callback.answer(
                "😔 Ошибка создания счета. Попробуйте позже.",
                show_alert=True
            )
            return
        
        # Сохраняем счет
        invoice_id = invoice.get("invoice_id")
        pending_invoices[invoice_id] = {
            "user_id": user_id,
            "amount": amount,
            "currency": "TON"
        }
        
        # Получаем ссылку для оплаты
        pay_url = crypto_service.get_payment_url(invoice)
        
        # Конвертируем TON в рубли (примерный курс)
        rub_amount = amount * 50  # 1 TON ≈ 50₽
        
        text = f"""
💳 <b>Счет создан!</b>

💰 <b>Сумма:</b> {amount} TON (≈{rub_amount}₽)
🆔 <b>Номер счета:</b> <code>{invoice_id}</code>

Нажмите кнопку "Оплатить" для перехода к оплате.
После оплаты нажмите "Я оплатил" для проверки платежа.

⏱ <i>Счет действителен 15 минут</i>
"""
        
        await callback.message.edit_text(
            text,
            reply_markup=get_payment_confirmation_menu(pay_url),
            parse_mode="HTML"
        )
        await callback.answer()
        logger.info(f"Создан счет {invoice_id} для пользователя {user_id}")
        
    except Exception as e:
        logger.error(f"Ошибка создания счета: {e}")
        await callback.answer(
            "😔 Ошибка создания счета",
            show_alert=True
        )


async def check_payment_status(
    callback: CallbackQuery,
    crypto_service: CryptoPaymentService,
    user_service: UserService
):
    """Проверить статус платежа"""
    try:
        user_id = callback.from_user.id
        
        # Находим счет пользователя
        user_invoice = None
        invoice_id = None
        
        for inv_id, inv_data in pending_invoices.items():
            if inv_data["user_id"] == user_id:
                user_invoice = inv_data
                invoice_id = inv_id
                break
        
        if not user_invoice:
            await callback.answer(
                "❌ Счет не найден",
                show_alert=True
            )
            return
        
        # Проверяем статус
        status = await crypto_service.check_invoice_status(invoice_id)
        
        if status == "paid":
            # Платеж прошел - начисляем баланс
            amount_ton = user_invoice["amount"]
            amount_rub = amount_ton * 50  # Конвертируем в рубли
            
            # Обновляем баланс
            await user_service.update_balance(user_id, amount_rub)
            
            # Удаляем счет из pending
            del pending_invoices[invoice_id]
            
            text = f"""
✅ <b>Платеж успешно получен!</b>

💰 Зачислено: <b>{amount_rub}₽</b>
🪙 Оплачено: {amount_ton} TON

Спасибо за пополнение! 🎉
"""
            await callback.message.edit_text(
                text,
                reply_markup=get_main_menu(),
                parse_mode="HTML"
            )
            await callback.answer("✅ Баланс пополнен!", show_alert=False)
            logger.info(f"Платеж {invoice_id} подтвержден для пользователя {user_id}")
            
        elif status == "active":
            await callback.answer(
                "⏳ Платеж еще не получен. Пожалуйста, завершите оплату.",
                show_alert=True
            )
            
        elif status == "expired":
            await callback.answer(
                "⏱ Срок действия счета истек. Создайте новый счет.",
                show_alert=True
            )
            del pending_invoices[invoice_id]
            
        else:
            await callback.answer(
                "❓ Неизвестный статус платежа",
                show_alert=True
            )
            
    except Exception as e:
        logger.error(f"Ошибка проверки платежа: {e}")
        await callback.answer(
            "😔 Ошибка проверки платежа",
            show_alert=True
        )


async def handle_coming_soon(callback: CallbackQuery, feature: str):
    """Обработчик для функций "скоро" """
    await callback.answer(
        f"🔜 {feature} будет доступен в следующих версиях!",
        show_alert=True
    )


async def handle_ton_amount_1(callback: CallbackQuery, crypto_service: CryptoPaymentService):
    await create_ton_invoice(callback, crypto_service, 1)

async def handle_ton_amount_5(callback: CallbackQuery, crypto_service: CryptoPaymentService):
    await create_ton_invoice(callback, crypto_service, 5)

async def handle_ton_amount_10(callback: CallbackQuery, crypto_service: CryptoPaymentService):
    await create_ton_invoice(callback, crypto_service, 10)

async def handle_ton_amount_25(callback: CallbackQuery, crypto_service: CryptoPaymentService):
    await create_ton_invoice(callback, crypto_service, 25)

async def handle_ton_amount_50(callback: CallbackQuery, crypto_service: CryptoPaymentService):
    await create_ton_invoice(callback, crypto_service, 50)

async def handle_ton_amount_100(callback: CallbackQuery, crypto_service: CryptoPaymentService):
    await create_ton_invoice(callback, crypto_service, 100)


def register_handlers(router: Router):
    """Регистрация обработчиков платежей"""
    router.callback_query.register(show_payment_menu, lambda c: c.data == "payment_menu")
    router.callback_query.register(show_ton_amount_menu, lambda c: c.data == "pay_ton")
    router.callback_query.register(check_payment_status, lambda c: c.data == "check_payment")
    
    # Обработчики выбора суммы
    router.callback_query.register(handle_ton_amount_1, lambda c: c.data == "ton_amount_1")
    router.callback_query.register(handle_ton_amount_5, lambda c: c.data == "ton_amount_5")
    router.callback_query.register(handle_ton_amount_10, lambda c: c.data == "ton_amount_10")
    router.callback_query.register(handle_ton_amount_25, lambda c: c.data == "ton_amount_25")
    router.callback_query.register(handle_ton_amount_50, lambda c: c.data == "ton_amount_50")
    router.callback_query.register(handle_ton_amount_100, lambda c: c.data == "ton_amount_100")
    
    # Обработчики "скоро"
    router.callback_query.register(
        lambda c: handle_coming_soon(c, "USDT платежи"),
        lambda c: c.data == "pay_usdt_soon"
    )
    router.callback_query.register(
        lambda c: handle_coming_soon(c, "Оплата картой"),
        lambda c: c.data == "pay_card_soon"
    )
